print """enum ChuckDedicationType = NoChuckDedication, DedicatedToCH0, DedicatedToCH1, Unknown;"""
